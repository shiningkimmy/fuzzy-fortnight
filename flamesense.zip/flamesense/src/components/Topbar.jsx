import React from 'react'
import './topbar.css'

export default function Topbar(){
  return (
    <header className="topbar">
      <div />
      <div className="topbar-right">
        <div className="lang">ENG ▾</div>
        <div className="profile">
          <div className="avatar">J</div>
          <div className="username">John ▾</div>
        </div>
      </div>
    </header>
  )
}
