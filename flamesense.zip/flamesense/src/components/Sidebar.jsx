import React from 'react'
import './sidebar.css'

export default function Sidebar(){
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="logo">🔥</div>
        <div className="brand-text">FlameSense</div>
      </div>

      <nav className="menu">
        <a className="menu-item active"><span className="icon">🏠</span>Home</a>
        <a className="menu-item"><span className="icon">🔔</span>Alerts</a>
        <a className="menu-item"><span className="icon">📊</span>Analytics & Summary</a>
        <a className="menu-item"><span className="icon">⚙️</span>Device Health</a>
      </nav>
    </aside>
  )
}
