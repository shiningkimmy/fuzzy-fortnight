import React, { useEffect, useState } from 'react'
import './dashboard.css'

// small presentational card
function Card({title, children, className=''}) {
  return (
    <div className={`card ${className}`}>
      {title && <div className="card-title">{title}</div>}
      <div className="card-body">{children}</div>
    </div>
  )
}

export default function Dashboard(){
  // placeholders for data coming from API
  const [data, setData] = useState({
    greeting: { name: 'John', time: '10:30 PM | July 3, 2025', place: 'B5 L12 P St., Brgy. Uno' },
    flame: { status: 'NO FLAME DETECTED', severity: 'normal' },
    temp: 25,
    humidity: 92,
    smoke: 40,
    power: { solar: 'Active', status: 'Power Source Available' },
  })

  // example fetch to backend (replace the URL with your real API)
  useEffect(() => {
    // Uncomment and change URL when your API is ready:
    /*
    fetch('/api/dashboard')
      .then(r => r.json())
      .then(payload => setData(payload))
      .catch(err => console.error('fetch dashboard error', err))
    */
  }, [])

  return (
    <div className="dashboard-grid">
      <div className="col-left">
        <Card>
          <div className="greeting">
            <small>Hi, {data.greeting.name}</small>
            <h2>Good morning!</h2>
            <div className="muted">{data.greeting.time}</div>
            <div className="muted">{data.greeting.place}</div>
          </div>
        </Card>

        <div className="small-cards">
          <Card className="gradient-temp">
            <div className="big-number">{data.temp}°C</div>
            <div className="muted">Room Temperature</div>
          </Card>

          <Card className="gradient-humid">
            <div className="big-number">{data.humidity}%</div>
            <div className="muted">Humidity</div>
          </Card>

          <Card className="gray-card">
            <div className="big-number">{data.smoke}</div>
            <div className="muted">Smoke (ppm)</div>
          </Card>
        </div>

        <Card>
          <div className="power-row">
            <div>
              <h4>Power Status</h4>
              <div className="muted">Solar Panel: {data.power.solar}</div>
              <div className="muted">Status: {data.power.status}</div>
            </div>
            <div className="power-icon">🔥</div>
          </div>
        </Card>
      </div>

      <div className="col-right">
        <Card className="flame-card">
          <div className="flame-title">Flame Detection</div>
          <h3 className="flame-status">{data.flame.status}</h3>
          <div className="muted">No threat detected</div>
        </Card>

        <Card>
          <h4>Reminders</h4>
          <ul>
            <li>Keep your solar panel clean for better charging.</li>
            <li>Have a fire extinguisher nearby.</li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
